# FLONGA — Stage 46: Moon Mushroom Village

GitHub Pages-ready Three.js browser game.

Features:
- Enchanted mushroom forest fashion village
- 85 procedural trees and 28 giant glowing mushrooms
- 8 woodland fashion stores
- SAVYS FOREST, MESSY MOSS, MUSHROOM SNEAKERS
- WOODLAND ACCESSORIES, MOON BOUTIQUE, FAIRY STREET
- FOREST MARKET and MOONLIGHT VIP
- 46 Moon Shrooms
- 140 Coins
- 245 NPC visitors
- 9 moving woodland creatures
- 90 floating fireflies
- Glowing forest path
- Interactive Moon Mushroom Core
- Forest Monarch Outfit — $13,000
- Energy + sprint
- 530-second challenge
- Mobile + keyboard controls

Controls:
WASD = Move
E / INTERACT = Interact
Shift / SPRINT = Sprint
