# FLONGA — Stage 43: Frost Kingdom

GitHub Pages-ready Three.js browser game.

Features:
- Enchanted winter kingdom
- Ice castle and royal towers
- 8 winter fashion stores
- SAVYS FROST, MESSY ICE, GLACIER SNEAKERS
- ICE ACCESSORIES, AURORA BOUTIQUE, SNOW STREET
- WINTER MARKET and ICE PALACE VIP
- 40 Ice Crowns
- 125 coins
- 225 NPC visitors
- 8 moving snow vehicles
- Aurora sky effects and snowfall
- Interactive Crystal Throne
- Frost Monarch Outfit — $11,500
- Energy + sprint
- 500-second challenge
- Mobile + keyboard controls

Controls:
WASD = Move
E / INTERACT = Interact
Shift / SPRINT = Sprint
