# FLONGA — Stage 22: Royal Garden Market

GitHub Pages-ready Three.js browser game.

## Features
- Royal garden shopping district
- 8 themed shops
- SAVYS Garden, Royal Fashion, Floral Boutique, Garden Shoes, Crown Accessories
- Botanic Style, Palace Market, Tea & Gifts
- Central royal fountain
- 12 collectible Golden Flowers
- 36 collectible coins
- 68 NPC shoppers
- Moving cars
- Garden trees, greenery and palace-market architecture
- Garden Royale outfit unlock
- Energy and sprint system
- 280-second challenge
- Mobile touch + keyboard controls

## Controls
WASD = move
E / INTERACT = interact
Shift / SPRINT = sprint

## Mission
Enter Royal Garden → collect 12 Golden Flowers → collect 36 Coins → visit 6 shops → activate the Royal Fountain → unlock Garden Royale Outfit.
