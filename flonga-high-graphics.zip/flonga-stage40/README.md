# FLONGA — Stage 40: Royal Sky Palace

Major 40/50 milestone stage.

Features:
- Massive floating royal palace
- 8 luxury royal fashion stores
- SAVYS ROYALE, MESSY COUTURE, ROYAL SNEAKERS
- CROWN ACCESSORIES, SKY BOUTIQUE, PALACE STREET
- ROYAL MARKET and EMPEROR VIP
- 35 Crown Jewels
- 110 coins
- 195 NPC visitors
- 12 royal guards
- 8 moving airships
- Glass sky bridges
- Palace towers and floating clouds
- Interactive Royal Sky Core
- Sky Emperor Outfit — $10,000
- Energy + sprint
- 470-second challenge
- 40 / 50 milestone overlay
- Mobile + keyboard controls

Controls:
WASD = Move
E / INTERACT = Interact
Shift / SPRINT = Sprint
