# FLONGA Stage 7 — Sneaker Street

Missions:
1. Enter Sneaker Street
2. Find 3 rare sneakers
3. Collect 10 coins
4. Visit Sports Lab

A 120-second sneaker-hunt timer is displayed. Controls: WASD/Arrow Keys, Shift to sprint, E to interact.
Upload index.html to GitHub Pages.
