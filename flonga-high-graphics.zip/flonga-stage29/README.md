# FLONGA — Stage 29: Rooftop Fashion City

GitHub Pages-ready Three.js browser game.

Features:
- Rooftop fashion district and skyline towers
- 8 rooftop stores
- 14 Star Badge collectibles
- 50 coins
- 92 NPC shoppers
- 8 flying vehicles
- Rooftop bridges and platforms
- Interactive Sky Elevator
- Skyline Royal outfit unlock ($4,200)
- Energy + sprint
- 350-second challenge
- Mobile + keyboard controls

Controls: WASD move, E/INTERACT interact, Shift/SPRINT sprint.
