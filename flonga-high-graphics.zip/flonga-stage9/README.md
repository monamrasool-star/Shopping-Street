# FLONGA Stage 9 — Mall Road

Missions:
1. Enter Mall Road
2. Visit 5 stores
3. Collect 15 coins
4. Reach the parking plaza

Features: 8 stores, mall-style interior area, parking plaza, 32 NPCs, lighting, coins, mobile controls and sprint.
Controls: WASD/Arrow Keys, Shift, E.
Upload index.html to GitHub Pages.
