# FLONGA — Stage 39: Cyber Metro City

GitHub Pages-ready Three.js browser game.

Features:
- Underground cyberpunk metro city
- 8 cyber fashion stores
- SAVYS CYBER, MESSY NEON, QUANTUM SNEAKERS
- HOLO ACCESSORIES, NIGHT BOUTIQUE, METRO STREET
- CYBER MARKET and REACTOR VIP
- 32 Neon Core collectibles
- 100 coins
- 180 NPC commuters
- 4 moving metro trains
- 8 security drones
- Central Station and tunnel architecture
- Interactive Neon Reactor override
- Cyber Monarch Outfit — $9,000
- Energy + sprint
- 450-second challenge
- Mobile + keyboard controls

Controls:
WASD = Move
E / INTERACT = Interact
Shift / SPRINT = Sprint
