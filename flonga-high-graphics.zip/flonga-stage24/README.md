# FLONGA — Stage 24: Winter Fashion Village

GitHub Pages-ready Three.js browser game.

## Features
- Snowy winter shopping village
- 8 winter-themed shops
- SAVYS Winter, Messy Outerwear, Frost Sneakers, Ice Accessories, Snow Boutique
- Alpine Style, Nordic Market, Cocoa & Gifts
- Central village fireplace
- 10 collectible Crystal Snowflakes
- 40 collectible coins
- 76 NPC shoppers
- Moving mountain cable cars
- Snowy hills and pine forest
- Warmth survival mechanic
- Arctic Luxe outfit unlock
- 300-second challenge
- Mobile touch + keyboard controls

## Controls
WASD = move
E / INTERACT = interact
Shift / SPRINT = sprint

## Mission
Enter Winter Village → collect 10 Crystal Snowflakes → collect 40 Coins → visit 6 Winter Shops → light the Village Fireplace → unlock Arctic Luxe Outfit.
