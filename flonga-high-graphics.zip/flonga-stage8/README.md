# FLONGA Stage 8 — Color Avenue

Missions:
1. Enter Color Avenue
2. Match 4 color displays
3. Collect 12 coins
4. Visit Color Lab

Controls: WASD/Arrow Keys, Shift to sprint, E to interact.
Upload index.html to GitHub Pages.
