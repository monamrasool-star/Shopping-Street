# FLONGA — Stage 33: Botanical Fashion Conservatory

GitHub Pages-ready Three.js browser game.

Features:
- Giant glass-roofed botanical conservatory
- 8 garden fashion stores
- SAVYS BOTANICA, MESSY GARDEN, FLORAL SNEAKERS, LEAF ACCESSORIES
- GREENHOUSE BOUTIQUE, ORCHID STYLE, BOTANICAL MARKET, ROYAL GARDEN VIP
- 20 Rare Flower collectibles
- 70 coins
- 122 NPC visitors
- Animated butterflies
- Water channels and waterfalls
- Garden transport carts
- Interactive Glasshouse Fountain
- Botanical Royal Outfit — $6,000
- Energy + sprint
- 390-second challenge
- Mobile + keyboard controls

Controls:
WASD = Move
E / INTERACT = Interact
Shift / SPRINT = Sprint
