# FLONGA — Stage 49: Celestial Cloud Kingdom

GitHub Pages-ready Three.js browser game.

Features:
- Giant celestial cloud kingdom
- 20 floating islands
- 30 celestial towers
- 12 illuminated star bridges
- 5 giant moon rings
- 8 celestial fashion stores
- SAVYS CELESTIAL, MESSY CLOUD, STAR SNEAKERS
- CROWN ACCESSORIES, HEAVEN BOUTIQUE, ANGEL STREET
- SKY MARKET and CELESTIAL VIP
- 49 Star Crowns
- 155 Coins
- 275 NPC visitors
- 7 moving sky trains
- 12 flying birds
- Celestial Crown Core
- Sky Monarch Outfit — $15,000
- Energy + sprint
- 560-second challenge
- Final-stage teaser
- Mobile + keyboard controls

Controls:
WASD = Move
E / INTERACT = Interact
Shift / SPRINT = Sprint
