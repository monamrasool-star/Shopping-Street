# FLONGA — Stage 47: Crystal Volcano City

GitHub Pages-ready Three.js browser game.

Features:
- Volcanic crystal canyon fashion metropolis
- 7 lava volcano formations
- 25 obsidian towers
- 35 glowing crystal clusters
- Lava channels and industrial atmosphere
- 8 volcano fashion stores
- SAVYS MAGMA, MESSY LAVA, CRYSTAL SNEAKERS
- OBSIDIAN ACCESSORIES, VOLCANO BOUTIQUE, LAVA STREET
- CRYSTAL MARKET and FORGE VIP
- 47 Crystal Shards
- 145 Coins
- 255 NPC visitors
- 7 moving mine carts
- 100 floating fire sparks
- Interactive Crystal Forge Core
- Magma Monarch Outfit — $13,500
- Energy + sprint
- 540-second challenge
- Mobile + keyboard controls

Controls:
WASD = Move
E / INTERACT = Interact
Shift / SPRINT = Sprint
