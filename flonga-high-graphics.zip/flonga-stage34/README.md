# FLONGA — Stage 34: Alpine Fashion Resort

GitHub Pages-ready Three.js browser game.

Features:
- Snow-covered alpine fashion resort
- 8 ski/fashion stores
- SAVYS ALPINE, MESSY SNOW, FROST SNEAKERS, ICE ACCESSORIES
- ALPINE BOUTIQUE, SKI STYLE, MOUNTAIN MARKET, SUMMIT VIP
- 22 Ice Crystal collectibles
- 75 coins
- 130 NPC skiers/shoppers
- Moving cable-car gondolas
- Pine forest and mountain scenery
- Animated snowfall
- Mountain Summit activation
- Alpine Legend Outfit — $6,500
- Energy + sprint
- 400-second challenge
- Mobile + keyboard controls

Controls:
WASD = Move
E / INTERACT = Interact
Shift / SPRINT = Sprint
