# FLONGA Stage 18 — Airport Fashion Terminal

Airport shopping stage with 8 terminal stores, departure hall, check-in counters, aircraft silhouettes, moving planes, luggage carts, 56 traveler NPCs, 5 travel bags, 28 coins and Jetsetter Look purchase.

Objectives:
1. Enter the Terminal
2. Collect 5 travel bags
3. Collect 28 coins
4. Visit the departure hall
5. Buy the Jetsetter Look for $1,500

Controls: WASD/Arrow Keys, Shift Sprint, E Interact.
Upload index.html to GitHub Pages.
