# FLONGA — Stage 37: Rainforest Fashion Canopy

GitHub Pages-ready Three.js browser game.

Features:
- Dense rainforest fashion environment
- 8 elevated treehouse stores
- SAVYS CANOPY, MESSY JUNGLE, RAINFOREST SNEAKERS
- LEAF ACCESSORIES, MONSOON BOUTIQUE, VINE STREET
- CANOPY MARKET and TEMPLE VIP
- 28 Emerald Leaf collectibles
- 90 coins
- 155 NPC visitors
- 9 flying birds
- Fireflies, giant trees and waterfalls
- Rope/canopy bridges
- Hidden Temple Vault with unlock mechanic
- Jungle Monarch Outfit — $8,000
- Energy + sprint
- 430-second challenge
- Mobile + keyboard controls

Controls:
WASD = Move
E / INTERACT = Interact
Shift / SPRINT = Sprint
