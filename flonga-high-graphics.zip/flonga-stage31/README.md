# FLONGA — Stage 31: Floating Fashion Islands

GitHub Pages-ready Three.js browser game.

Features:
- Floating island fashion city above the clouds
- 8 island stores
- SAVYS CLOUD, MESSY SKY, AERO SNEAKERS, PEARL ACCESSORIES
- CLOUD BOUTIQUE, ISLAND STYLE, SKY MARKET, ROYAL CLOUD
- 16 Sky Pearl collectibles
- 60 coins
- 108 NPC shoppers
- Flying air vehicles
- Cloud environment and floating islands
- Interactive Sky Tram
- Cloud Monarch Outfit — $5,200
- Energy + sprint
- 370-second challenge
- Mobile + keyboard controls

Controls:
WASD = Move
E / INTERACT = Interact
Shift / SPRINT = Sprint
