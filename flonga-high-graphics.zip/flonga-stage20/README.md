# FLONGA — Stage 20: Desert Shopping Oasis

GitHub Pages-ready browser game prototype.

## Features
- Large desert shopping oasis environment
- 8 interactive shopping locations
- SAVYS Desert, Sandstorm Fashion, Caravan Shoes, Oasis Accessories, Sunset Boutique
- Mirage Market, Gold Souk, Palm Cafe
- Central interactive oasis fountain
- 8 glowing desert gems
- 32 collectible coins
- 60 NPC shoppers/villagers
- Moving desert traffic
- Palm trees, dunes, sunset lighting and oasis architecture
- Desert Explorer outfit unlock
- 250-second challenge timer
- Water/sprint system
- Keyboard and mobile touch controls
- Stage-completion system

## Controls
- WASD / Arrow-style on-screen controls: move
- E or INTERACT: interact with shops/fountain
- Shift or SPRINT: sprint
- On mobile, use the touch controls.

## Run
Open `index.html` in a modern browser or publish the folder with GitHub Pages.

## Objective
1. Enter Oasis
2. Find 8 Desert Gems
3. Collect 32 Coins
4. Visit 6 Shops
5. Activate Oasis Fountain
6. Buy/unlock Desert Explorer Outfit
