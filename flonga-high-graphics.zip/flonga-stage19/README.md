# FLONGA Stage 19 — Mountain Village Market

Mountain shopping stage with 8 rustic cabins/stores, SAVYS Alpine, craft market, mountain silhouettes, pine trees, bridge, moving cable cars, 58 villagers, 8 crystals, 30 coins and Alpine Outfit purchase.

Objectives:
1. Reach the mountain village
2. Find 8 mountain crystals
3. Collect 30 coins
4. Visit the craft market
5. Buy the Alpine Outfit for $1,700

Controls: WASD/Arrow Keys, Shift Sprint, E Interact.
Upload index.html to GitHub Pages.
