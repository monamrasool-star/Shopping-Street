# FLONGA Stage 6 — Food Street

Missions:
1. Enter Food Street
2. Collect 12 coins
3. Buy Street Food ($100)
4. Visit Dessert Café

Controls: WASD/Arrow Keys = Move, Shift = Sprint, E = Interact.
Upload index.html to GitHub and enable GitHub Pages.
