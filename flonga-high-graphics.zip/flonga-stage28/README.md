# FLONGA — Stage 28: Neon Carnival District

GitHub Pages-ready Three.js browser game.

## Features
- Neon carnival shopping district
- 8 carnival shops
- SAVYS Carnival, Messy Arcade, Prize Sneakers, Glow Accessories, Midnight Boutique
- Funhouse Style, Carnival Market, Ticket Gifts
- Interactive Ferris wheel
- 12 collectible Golden Tickets
- 48 collectible coins
- 94 NPC visitors
- Multiple carnival rides
- Carnival Icon outfit unlock
- Energy + sprint system
- 340-second challenge
- Mobile touch + keyboard controls

## Controls
WASD = move
E / INTERACT = interact
Shift / SPRINT = sprint

## Mission
Enter Neon Carnival → collect 12 Golden Tickets → collect 48 Coins → visit 6 Carnival Shops → start the Ferris Wheel → unlock Carnival Icon Outfit.
