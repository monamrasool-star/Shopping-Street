# FLONGA — High Graphics 50 Stage Edition

Three.js browser game hub for 50 fashion-shopping stages.

The main page is an upgraded 3D metropolis with dynamic lighting, fog, shadows, metallic materials, animated 3D character, vehicles and a 50-stage launcher. Each stage remains a separate playable prototype.

Upload the CONTENTS of this folder to the repository root for GitHub Pages.
