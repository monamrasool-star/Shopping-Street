# FLONGA — Stage 25: Future Tech Plaza

GitHub Pages-ready Three.js browser game.

## Features
- Futuristic technology shopping district
- 8 tech/fashion stores
- SAVYS Tech, Messy Cyber, Robot Sneakers, Holo Accessories, Nova Devices
- Pixel Lab, Neon Market, AI Fashion
- Central holographic Holo Core
- 10 collectible Quantum Chips
- 42 collectible coins
- 82 NPCs including robots
- 7 moving hover vehicles
- Cyber Luxe outfit unlock
- Battery/boost mechanic
- 310-second challenge
- Mobile touch + keyboard controls

## Controls
WASD = move
E / INTERACT = interact
Shift / BOOST = boost

## Mission
Enter Tech Plaza → collect 10 Quantum Chips → collect 42 Coins → visit 6 Tech Stores → activate Holo Core → unlock Cyber Luxe Outfit.
