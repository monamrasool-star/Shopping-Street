# FLONGA — Stage 41: Atlantis Fashion Ruins

GitHub Pages-ready Three.js browser game.

Features:
- Ancient underwater-inspired fashion ruins
- 8 Atlantis fashion stores
- SAVYS ATLANTIS, MESSY ABYSS, TRIDENT SNEAKERS
- CORAL ACCESSORIES, PEARL BOUTIQUE, RUIN STREET
- OCEAN MARKET and TEMPLE VIP
- 36 Ancient Pearl collectibles
- 115 coins
- 205 NPC divers
- 16 swimming fish
- 7 moving manta-style gliders
- Ruined columns and arches
- Glass tunnel structures
- Interactive Pearl Temple unlock
- Atlantis Monarch Outfit — $10,500
- Energy + sprint
- 480-second challenge
- Mobile + keyboard controls

Controls:
WASD = Move
E / INTERACT = Interact
Shift / SPRINT = Sprint
