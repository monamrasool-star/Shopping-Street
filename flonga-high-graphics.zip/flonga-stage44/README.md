# FLONGA — Stage 44: Golden Pharaoh City

GitHub Pages-ready Three.js browser game.

Features:
- Ancient Egyptian-inspired fashion metropolis
- Pyramids, obelisks and royal palace
- 8 Pharaoh fashion stores
- SAVYS PHARAOH, MESSY NILE, SCARAB SNEAKERS
- GOLD ACCESSORIES, SUN BOUTIQUE, DESERT STREET
- ROYAL MARKET and PHARAOH VIP
- 42 Sun Relics
- 130 coins
- 235 NPC visitors
- 8 moving camel caravans
- Oasis and palm garden
- Sandstorm-style desert atmosphere
- Interactive Golden Pharaoh Core
- Pharaoh Monarch Outfit — $12,000
- Energy + sprint
- 510-second challenge
- Mobile + keyboard controls

Controls:
WASD = Move
E / INTERACT = Interact
Shift / SPRINT = Sprint
