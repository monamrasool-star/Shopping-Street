# FLONGA Stage 15 — Fashion Night Runway

Night fashion-event stage with an illuminated runway, 8 fashion stores, storefront displays, 6 collectible fashion gems, 24 coins, 52 NPCs, VIP Fashion, Runway Look purchase and mobile/keyboard controls.

Objectives:
1. Enter the Runway District
2. Collect 6 fashion gems
3. Collect 24 coins
4. Walk the illuminated runway
5. Buy the Runway Look for $1,000

Controls: WASD/Arrow Keys, Shift Sprint, E Interact.
Upload index.html to GitHub Pages.
