# FLONGA — Stage 27: Tropical Resort Walk

GitHub Pages-ready Three.js browser game.

## Features
- Tropical resort shopping district
- 8 resort stores
- SAVYS Resort, Messy Beach, Palm Sneakers, Coral Accessories, Sunset Boutique
- Island Style, Ocean Market, Tiki Gifts
- Beach Club and resort pool
- 12 collectible Pearl Shells
- 46 collectible coins
- 88 NPC tourists
- 7 moving sailboats
- Tropical Luxe outfit unlock
- Energy + sprint system
- 330-second challenge
- Mobile touch + keyboard controls

## Controls
WASD = move
E / INTERACT = interact
Shift / SPRINT = sprint

## Mission
Enter Tropical Resort → collect 12 Pearl Shells → collect 46 Coins → visit 6 Resort Stores → activate Beach Club → unlock Tropical Luxe Outfit.
