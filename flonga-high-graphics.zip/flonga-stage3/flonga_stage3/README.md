# FLONGA — Stage 3: Local Bazaar

A browser-playable Three.js prototype for the third stage of the 50-stage Flonga Street Shopping Game.

## Stage objective
1. Visit the Festival stall.
2. Collect 10 coins.
3. Buy a Festival Outfit.
4. Find the Secret Stall.

## Controls
WASD / Arrow keys = Move
SHIFT = Sprint
E = Interact

## Run
Open `index.html` in a modern browser, or upload the folder to GitHub and enable GitHub Pages.

## Note
Three.js is loaded from jsDelivr, so the browser needs internet access.
