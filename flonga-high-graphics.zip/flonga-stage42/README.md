# FLONGA — Stage 42: Inferno Fashion Fortress

GitHub Pages-ready Three.js browser game.

Features:
- Giant volcanic fortress city
- 8 inferno fashion stores
- SAVYS INFERNO, MESSY MAGMA, VOLCANO SNEAKERS
- OBSIDIAN ACCESSORIES, FIRE BOUTIQUE, ASH STREET
- LAVA MARKET and FORGE VIP
- 38 Magma Shards
- 120 coins
- 215 NPC visitors
- 9 moving fire drones
- Lava rivers and obsidian towers
- Glowing magma bridges
- Interactive Inferno Forge
- Inferno Monarch Outfit — $11,000
- Energy + sprint
- 490-second challenge
- Mobile + keyboard controls

Controls:
WASD = Move
E / INTERACT = Interact
Shift / SPRINT = Sprint
