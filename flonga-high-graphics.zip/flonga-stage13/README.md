# FLONGA Stage 13 — Luxury Boulevard

Premium evening boulevard stage with 8 luxury storefronts, storefront interiors/displays, VIP showroom, gold lighting, 44 NPCs, 20 coins, Elite Outfit purchase and mobile/keyboard controls.

Objectives:
1. Enter Luxury Boulevard
2. Visit 5 luxury stores
3. Collect 20 gold coins
4. Find the VIP showroom
5. Buy the Elite Outfit for $700

Controls: WASD/Arrow Keys, Shift Sprint, E Interact.
Upload index.html to GitHub Pages.
