# FLONGA — Stage 38: Orbital Fashion Spaceport

GitHub Pages-ready Three.js browser game.

Features:
- Futuristic orbital spaceport
- 8 space fashion stores
- SAVYS ORBIT, MESSY GALAXY, ZERO-G SNEAKERS
- COSMIC ACCESSORIES, STAR BOUTIQUE, MOON STREET
- NEBULA MARKET and COMMANDER VIP
- 30 Star Chip collectibles
- 95 coins
- 165 NPC travelers
- 7 moving space shuttles
- Launch pads and shuttle hangars
- Space Core charging mechanic
- Galaxy Monarch Outfit — $8,500
- Energy + sprint
- 440-second challenge
- Mobile + keyboard controls

Controls:
WASD = Move
E / INTERACT = Interact
Shift / SPRINT = Sprint
