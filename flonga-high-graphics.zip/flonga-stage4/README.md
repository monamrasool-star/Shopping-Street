# FLONGA — Stage 4: Fashion District

Playable Three.js browser stage.

## Mission
1. Visit Fashion House
2. Collect 12 coins
3. Buy the Luxury Outfit at Luxe Boutique ($250)
4. Visit Shoe Gallery

## Controls
WASD / Arrow Keys = Move
Shift = Sprint
E = Interact
Mobile touch buttons are included.

## GitHub Pages
Upload `index.html` to a repository and enable GitHub Pages from Settings → Pages → Deploy from branch.
