# FLONGA Stage 17 — Coastal Shopping Pier

Coastal shopping stage with 8 boardwalk stores, SAVYS Beach, lighthouse, ocean, palm trees, 4 moving boats, 54 tourist NPCs, 7 pearl shells, 26 coins and a Coastal Look purchase.

Objectives:
1. Reach the Pier
2. Collect 7 pearl shells
3. Collect 26 coins
4. Visit the boardwalk market
5. Buy the Coastal Look for $1,350

Controls: WASD/Arrow Keys, Shift Sprint, E Interact.
Upload index.html to GitHub Pages.
