# FLONGA Stage 5 — Downtown Mega Mall

## Missions
- Enter Mega Mall
- Collect 15 coins
- Buy Designer Outfit ($400)
- Visit Floor 2

## Controls
WASD / Arrow Keys — Move
Shift — Sprint
E — Interact

Upload `index.html` to GitHub and enable GitHub Pages.
