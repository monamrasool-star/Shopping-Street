# FLONGA Stage 11 — Neon Market

Missions:
1. Enter Neon Market
2. Find 5 hidden neon items
3. Collect 15 coins
4. Discover the Secret Shop

Features: 8 neon shops, hidden collectibles, secret shop, neon lighting, 42 NPCs, timed 165-second challenge, mobile controls and sprint.
Controls: WASD/Arrow Keys, Shift, E.
Upload index.html to GitHub Pages.
