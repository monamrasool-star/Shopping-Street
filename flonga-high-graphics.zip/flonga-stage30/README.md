# FLONGA — Stage 30: Grand Fashion Festival

GitHub Pages-ready Three.js browser game.

## Features
- Grand fashion festival environment
- 8 festival shopping stores
- SAVYS Festival, Messy Runway, Crown Sneakers, Glam Accessories
- Festival Boutique, Designer Tent, Style Market, VIP Fashion
- Main illuminated fashion runway
- 15 Golden Crown collectibles
- 55 collectible coins
- 100 NPC festival crowd
- Moving parade floats
- Fireworks atmosphere
- Festival Legend Outfit unlock ($4,800)
- Energy + sprint system
- 360-second challenge
- Mobile + keyboard controls
- Stage 30 / 50 milestone

## Controls
WASD = Move
E / INTERACT = Interact
Shift / SPRINT = Sprint

## Mission
Enter Grand Festival → collect 15 Crowns → collect 55 Coins → visit 7 stores → light Main Runway → buy Festival Legend Outfit.
