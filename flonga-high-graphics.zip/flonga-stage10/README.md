# FLONGA Stage 10 — Night Market

Missions:
1. Enter Night Market
2. Visit 4 neon shops
3. Collect 15 glowing coins
4. Buy Night Outfit ($300)

Features: nighttime lighting, neon stores, night outfit purchase, 38 NPCs, moving cars with night atmosphere, glowing collectibles, 150-second timer, mobile controls and sprint.
Controls: WASD/Arrow Keys, Shift, E.
Upload index.html to GitHub Pages.
