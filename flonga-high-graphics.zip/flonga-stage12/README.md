# FLONGA Stage 12 — Busy Bazaar

A dense daytime/evening bazaar stage with 12 market stalls, 50 NPCs, moving traffic, 18 coins, pedestrian crossing, interiors/front displays, a Bazaar Outfit purchase and mobile/keyboard controls.

Objectives:
1. Enter the Bazaar
2. Visit 6 market stalls
3. Collect 18 coins
4. Cross the traffic lane safely
5. Buy the Bazaar Outfit for $450

Controls: WASD/Arrow Keys, Shift Sprint, E Interact.
Upload index.html to GitHub Pages.
