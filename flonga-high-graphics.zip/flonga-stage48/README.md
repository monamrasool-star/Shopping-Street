# FLONGA — Stage 48: Ocean Sky City

GitHub Pages-ready Three.js browser game.

Features:
- Futuristic floating ocean city
- 18 floating platforms
- 32 illuminated skyscrapers
- 10 glass bridges
- 8 underwater tunnel rings
- 18 animated ocean creatures
- 8 ocean fashion stores
- SAVYS OCEAN, MESSY WAVE, TIDAL SNEAKERS
- CORAL ACCESSORIES, DEEP BOUTIQUE, BLUE STREET
- OCEAN MARKET and ABYSS VIP
- 48 Tide Crystals
- 150 Coins
- 265 NPC visitors
- 8 moving hover boats
- 10 marine drones
- Tidal Energy Core
- Ocean Monarch Outfit — $14,000
- Energy + sprint
- 550-second challenge
- Mobile + keyboard controls

Controls:
WASD = Move
E / INTERACT = Interact
Shift / SPRINT = Sprint
