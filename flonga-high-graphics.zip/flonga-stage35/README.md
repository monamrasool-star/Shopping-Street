# FLONGA — Stage 35: Holo Desert Megacity

GitHub Pages-ready Three.js browser game.

Features:
- Futuristic desert megacity at night
- 8 holographic fashion stores
- SAVYS MIRAGE, MESSY HOLO, DUNE SNEAKERS, SUNSET ACCESSORIES
- MIRAGE BOUTIQUE, CYBER SOUK, HOLO MARKET, ROYAL MIRAGE
- 24 Holo Shard collectibles
- 80 coins
- 138 NPC shoppers
- 9 moving hover taxis
- Neon megacity towers and desert dunes
- Animated sandstorm atmosphere
- Interactive Holo Core
- Mirage Legend Outfit — $7,000
- Energy + sprint
- 410-second challenge
- Mobile + keyboard controls

Controls:
WASD = Move
E / INTERACT = Interact
Shift / SPRINT = Sprint
