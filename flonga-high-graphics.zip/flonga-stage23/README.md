# FLONGA — Stage 23: Harbor Fashion Port

GitHub Pages-ready Three.js browser game.

## Features
- Large waterfront fashion port
- 8 harbor shops
- SAVYS Harbor, Messy Dockwear, Sailor Sneakers, Marine Accessories, Sunset Boutique
- Anchor Style, Captain's Market, Port Gifts
- Fashion ferry
- Lighthouse, cargo cranes, warehouses and ocean
- 9 collectible Ocean Pearls
- 38 collectible coins
- 72 NPC shoppers/travelers
- 5 moving sailboats
- Harbor Captain outfit unlock
- Energy + sprint system
- 290-second challenge
- Mobile touch + keyboard controls

## Controls
WASD = move
E / INTERACT = interact
Shift / SPRINT = sprint

## Mission
Enter Harbor Port → collect 9 Ocean Pearls → collect 38 Coins → visit 6 Harbor Shops → board the Fashion Ferry → unlock Harbor Captain Outfit.
