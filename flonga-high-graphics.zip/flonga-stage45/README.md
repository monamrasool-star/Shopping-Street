# FLONGA — Stage 45: Steam Skyport

GitHub Pages-ready Three.js browser game.

Features:
- Giant steampunk skyport
- Elevated rail platforms and industrial towers
- Rotating giant gears and turbine towers
- 8 Airship fashion stores
- SAVYS AIR, MESSY STEAM, GEAR SNEAKERS
- BRASS ACCESSORIES, SKY BOUTIQUE, CLOUD STREET
- ENGINE MARKET and SKYPORT VIP
- 45 Gear Cores
- 135 Coins
- 235 NPC travelers
- 8 moving airships
- Floating cloud layers
- Interactive Sky Engine
- Airship Monarch Outfit — $12,500
- Energy + sprint
- 520-second challenge
- Mobile + keyboard controls

Controls:
WASD = Move
E / INTERACT = Interact
Shift / SPRINT = Sprint
