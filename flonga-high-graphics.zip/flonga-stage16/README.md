# FLONGA Stage 16 — Outlet Factory

Industrial shopping stage with factory outlet stores, production-floor interior, conveyor machines, cranes, delivery trucks, 46 workers/NPCs, 6 stock boxes, 25 coins and a Factory Exclusive purchase.

Objectives:
1. Enter the Factory Outlet
2. Collect 6 stock boxes
3. Collect 25 coins
4. Visit the production floor
5. Buy the Factory Exclusive for $1,200

Controls: WASD/Arrow Keys, Shift Sprint, E Interact.
Upload index.html to GitHub Pages.
