# FLONGA — Stage 32: Metro Fashion Underground

GitHub Pages-ready Three.js browser game.

Features:
- Underground metro fashion district
- 8 metro stores
- SAVYS METRO, MESSY EXPRESS, RAIL SNEAKERS, METRO ACCESSORIES
- UNDERGROUND BOUTIQUE, NIGHT PLATFORM, CENTRAL MARKET, VIP METRO
- 18 Metro Token collectibles
- 65 coins
- 115 NPC commuters
- 3 moving metro trains
- Underground tracks, platforms and stations
- Interactive Central Station
- Metro Icon Outfit — $5,600
- Energy + sprint
- 380-second challenge
- Mobile + keyboard controls

Controls:
WASD = Move
E / INTERACT = Interact
Shift / SPRINT = Sprint
