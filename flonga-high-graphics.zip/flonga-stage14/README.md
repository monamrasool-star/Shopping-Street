# FLONGA Stage 14 — Streetwear District

Urban streetwear stage featuring 8 stores, storefront interiors/displays, graffiti-tag activation, skate ramps, street props, 48 NPCs, 22 coins, Limited Drop outfit purchase and mobile/keyboard controls.

Objectives:
1. Enter the District
2. Visit 6 streetwear stores
3. Collect 22 coins
4. Activate 4 graffiti tags
5. Buy the Limited Drop for $850

Controls: WASD/Arrow Keys, Shift Sprint, E Interact.
Upload index.html to GitHub Pages.
