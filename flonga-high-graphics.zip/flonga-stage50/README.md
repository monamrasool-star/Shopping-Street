# FLONGA — Stage 50: Grand Fashion Metropolis

THE FINAL STAGE.

GitHub Pages-ready Three.js browser game.

Features:
- Giant Grand Fashion Metropolis
- Neon, Royal, Ocean, Forest and Central Mega Mall districts
- 5 landmark district hubs
- 14 procedural skyscrapers
- Elevated transit system
- 10 Grand fashion stores
- MESSY FLAGSHIP, SAVYS GLOBAL, CROWN SNEAKERS
- WORLD ACCESSORIES, FASHION HOUSE, STREET LAB
- LUXE AVENUE, GLOBAL VIP, MONARCH STORE, ULTIMATE STORE
- 50 Fashion Crowns
- 200 Coins
- 320 NPC visitors
- 10 moving fashion vehicles
- 180 floating celebration particles
- Giant Ultimate Fashion Core
- Global Fashion Monarch outfit
- 600-second final challenge
- Full mobile + keyboard controls
- Completion screen for 50 / 50 stages

Controls:
WASD = Move
E / INTERACT = Interact
Shift / SPRINT = Sprint

FINAL OBJECTIVE:
Complete all six missions to unlock GLOBAL FASHION MONARCH and finish the complete 50-stage FLONGA campaign.
