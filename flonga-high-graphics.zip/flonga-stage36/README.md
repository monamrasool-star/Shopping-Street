# FLONGA — Stage 36: Oceanfront Fashion Harbor

GitHub Pages-ready Three.js browser game.

Features:
- Futuristic oceanfront fashion harbor
- 8 harbor fashion stores
- SAVYS HARBOR, MESSY DOCKWEAR, SAILOR SNEAKERS, MARINE ACCESSORIES
- OCEAN BOUTIQUE, CAPTAIN STYLE, PORT MARKET, ADMIRAL VIP
- 26 Sea Gem collectibles
- 85 coins
- 145 NPC shoppers/travelers
- 8 moving boats
- 7 moving cargo carts
- Cargo cranes and harbor warehouses
- Interactive Lighthouse Beacon
- Ocean Monarch Outfit — $7,500
- Energy + sprint
- 420-second challenge
- Mobile + keyboard controls

Controls:
WASD = Move
E / INTERACT = Interact
Shift / SPRINT = Sprint
