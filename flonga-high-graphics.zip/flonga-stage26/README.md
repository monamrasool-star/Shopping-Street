# FLONGA — Stage 26: Ancient Royal Bazaar

GitHub Pages-ready Three.js browser game.

## Features
- Ancient royal shopping district
- 8 royal stalls
- SAVYS Royal, Messy Heritage, Royal Shoes, Gold Jewels, Sultan Boutique
- Carpet House, Spice Market, Royal Gifts
- Palace gate and royal fountain
- 11 collectible Golden Relics
- 44 collectible coins
- 84 NPC shoppers
- Moving merchant carts
- Royal Heirloom outfit unlock
- Stamina + sprint system
- 320-second challenge
- Mobile touch + keyboard controls

## Controls
WASD = move
E / INTERACT = interact
Shift / SPRINT = sprint

## Mission
Enter Royal Bazaar → collect 11 Golden Relics → collect 44 Coins → visit 6 Royal Stalls → unlock the Palace Gate → unlock Royal Heirloom Outfit.
