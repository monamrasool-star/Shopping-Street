# FLONGA — Stage 21: Skybridge Fashion City

GitHub Pages-ready Three.js browser-game prototype.

## Stage features
- Futuristic vertical fashion district
- 8 fashion towers
- SAVYS SKY, MESSY HIGH, Cloud Sneakers, Aero Accessories, Nova Boutique, Style Deck, Luxe Sky, Pixel Fashion
- Elevated skybridges and central glass elevator
- 10 glowing Sky Shards
- 34 collectible coins
- 64 NPC shoppers
- Flying delivery drones
- Skyline Outfit unlock
- Energy + sprint system
- 270-second challenge
- Mobile touch controls and keyboard controls

## Controls
WASD = move
E = interact
Shift = sprint
Mobile buttons = move/interact/sprint

## Mission
Enter Skybridge City → collect 10 Sky Shards → collect 34 coins → visit 6 towers → activate the central elevator → unlock the Skyline Outfit.
